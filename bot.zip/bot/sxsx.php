<?php
						// Configurações do banco de dados
						$servername = "localhost";
						$username = "root";
						$password = "";  // Senha vazia por padrão no XAMPP
						$dbname = "loga";

						// Criar conexão
						$conn = new mysqli($servername, $username, $password, $dbname);

						// Verificar a conexão
						if ($conn->connect_error) {
							die("Falha na conexão: " . $conn->connect_error);
						}

						// Consulta SQL para obter a contagem de voluntários
						$sql = "SELECT COUNT(*) as total_projetos FROM projetos";

						$result = $conn->query($sql);

						if ($result !== false) {
							// Exibir a quantidade de voluntários
							$row = $result->fetch_assoc();
							echo "<h3>" . $row["total_projetos"] . "</h3>";
						} else {
							echo "Erro na consulta: " . $conn->error;
						}

						// Fechar a conexão
						$conn->close();
						?>